plugins { id("com.android.application") }

android {
    namespace = "com.booth.player"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.booth.player"
        minSdk = 24
        targetSdk = 36
        versionCode = 400
        versionName = "0.4.0"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.8.0")
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.11.1")
    implementation("androidx.media3:media3-ui:1.11.1")
}
