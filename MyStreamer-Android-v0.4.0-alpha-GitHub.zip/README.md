# MyStreamer Android

Current release: **v0.4.0-alpha** (`versionCode 400`).

Android frontend for Stremio-compatible add-ons with native Android Media3 playback.

## v0.4.0-alpha
- Cinemeta/Torrentio-compatible web frontend packaged in the app.
- Direct HTTP/HLS sources open in the native Media3/ExoPlayer player.
- Torrent selections are passed to the Android bridge, but the native torrent engine is **not implemented yet**.
- Android TV launcher declaration is present; full D-pad/10-foot UI optimization is planned for a later release.

## Build APK with GitHub Actions
1. Upload this project to the root of the repository.
2. Open **Actions > Build Android APK**.
3. Run the workflow, or simply push to `main`.
4. Download the artifact named `MyStreamer-v0.4.0-alpha-debug`.

The workflow uses JDK 17, Android SDK 36 / Build Tools 36.0.0, and Gradle 9.6.0.

## Upgrade identity
The application ID is intentionally kept as `com.booth.player`. Do not change it after installing builds if you want Android to treat later releases as updates to the same app.

For reliable upgrades between CI-built APKs, a later release should use a persistent release signing key stored in GitHub Actions secrets. Debug builds are for initial testing.
