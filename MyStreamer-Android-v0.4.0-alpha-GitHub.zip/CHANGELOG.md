# Booth Android changelog

## 0.4.0 — 2026-09-19
- First Android/Android TV project.
- Existing Booth HTML UI packaged as an Android asset.
- Cinemeta + Torrentio manifests preconfigured.
- Native Media3/ExoPlayer activity for direct HTTP/HLS sources.
- Android phone launcher and Android TV Leanback launcher declarations.
- JavaScript bridge captures torrent infoHash/fileIdx.
- Torrent playback engine is **not yet implemented** in this release.
- Semantic versioning and monotonically increasing Android versionCode established.
